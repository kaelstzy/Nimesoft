type ActivePackageCardProps = {
  packageName: string;
  expiresLabel: string;
  daysLeft: number;
  totalDays: number;
};

export default function ActivePackageCard({
  packageName,
  expiresLabel,
  daysLeft,
  totalDays,
}: ActivePackageCardProps) {
  const percent = Math.max(0, Math.min(1, daysLeft / totalDays));
  const r = 26;
  const c = 2 * Math.PI * r;

  return (
    <section className="card-cut mx-5 mt-3 flex items-center justify-between border border-line bg-paper p-5">
      <div>
        <p className="text-[11px] uppercase tracking-wide text-muted">Paket Aktif</p>
        <p className="mt-1 text-[17px] font-semibold">{packageName}</p>
        <p className="mt-0.5 text-[12px] text-muted">Berakhir {expiresLabel}</p>
      </div>
      <div className="relative h-16 w-16 shrink-0">
        <svg viewBox="0 0 64 64" className="h-16 w-16 -rotate-90">
          <circle cx="32" cy="32" r={r} fill="none" stroke="#EAEAEA" strokeWidth="5" />
          <circle
            cx="32"
            cy="32"
            r={r}
            fill="none"
            stroke="#4F46E5"
            strokeWidth="5"
            strokeDasharray={c}
            strokeDashoffset={c * (1 - percent)}
            strokeLinecap="round"
          />
        </svg>
        <span className="absolute inset-0 flex items-center justify-center text-[12px] font-semibold">
          {daysLeft}d
        </span>
      </div>
    </section>
  );
}
