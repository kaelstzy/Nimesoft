import Link from "next/link";
import { IconChevron } from "@/components/icons";

export type ChangelogEntry = {
  date: string;
  text: string;
};

export default function Changelog({ entries }: { entries: ChangelogEntry[] }) {
  return (
    <section className="mt-7 flex-1 px-5 pb-28">
      <div className="mb-3 flex items-center justify-between">
        <p className="text-[11px] uppercase tracking-wide text-muted">Changelog</p>
        <Link href="/updates" className="flex items-center text-[12px] font-medium">
          Lihat semua <IconChevron className="h-3.5 w-3.5" />
        </Link>
      </div>
      <ul className="divide-y divide-line border-y border-line">
        {entries.map((entry, i) => (
          <li key={i} className="flex gap-4 py-3.5">
            <span className="w-12 shrink-0 pt-0.5 text-[11px] text-black/40">{entry.date}</span>
            <span className="text-[13px] leading-snug">{entry.text}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
