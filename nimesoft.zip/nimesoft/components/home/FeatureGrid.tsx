import Link from "next/link";
import { SVGProps } from "react";
import {
  IconBug,
  IconSignal,
  IconInfo,
  IconChannel,
  IconRedeem,
} from "@/components/icons";

type FeatureItem = {
  href: string;
  label: string;
  icon: (props: SVGProps<SVGSVGElement>) => JSX.Element;
};

const FEATURES: FeatureItem[] = [
  { href: "/report-bug", label: "Laporkan Bug", icon: IconBug },
  { href: "/bot-status", label: "Status Bot", icon: IconSignal },
  { href: "/updates", label: "Info Update", icon: IconInfo },
  { href: "/channel", label: "Saluran NimeSoft", icon: IconChannel },
  { href: "/redeem", label: "Redeem Code", icon: IconRedeem },
];

export default function FeatureGrid() {
  return (
    <section className="mt-6 px-5">
      <p className="mb-3 text-[11px] uppercase tracking-wide text-muted">Menu</p>
      <div className="grid grid-cols-3 gap-3">
        {FEATURES.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className="card-cut group flex flex-col items-start gap-3 border border-line bg-paper p-4 transition-colors hover:border-ink"
          >
            <span className="flex h-9 w-9 items-center justify-center border border-black/15 group-hover:border-ink">
              <Icon className="h-4.5 w-4.5" />
            </span>
            <span className="text-[13px] font-medium leading-tight">{label}</span>
          </Link>
        ))}
      </div>
    </section>
  );
}
