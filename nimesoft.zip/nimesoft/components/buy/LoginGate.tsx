"use client";

import { useState } from "react";

type LoginGateProps = {
  onLoggedIn: () => void;
};

export default function LoginGate({ onLoggedIn }: LoginGateProps) {
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);

  // TODO: ganti dengan panggilan endpoint bot beneran (kirim OTP via WA)
  function requestOtp() {
    if (!phone) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep("otp");
    }, 700);
  }

  // TODO: ganti dengan verifikasi OTP beneran ke backend
  function verifyOtp() {
    if (otp.length < 4) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLoggedIn();
    }, 700);
  }

  return (
    <div className="card-cut mx-5 mt-4 border border-line p-6">
      <p className="text-[15px] font-semibold">Masuk untuk lanjut membeli</p>
      <p className="mt-1 text-[12.5px] text-muted">
        Verifikasi nomor WhatsApp kamu terlebih dahulu.
      </p>

      {step === "phone" ? (
        <div className="mt-5">
          <label className="text-[11px] uppercase tracking-wide text-muted">Nomor WhatsApp</label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="628xxxxxxxxxx"
            inputMode="numeric"
            className="mt-1.5 w-full rounded-xl border border-line px-3 py-2.5 text-[14px] outline-none focus:border-ink"
          />
          <button
            onClick={requestOtp}
            disabled={loading || !phone}
            className="btn-primary mt-4 w-full py-3 text-[13.5px] font-semibold"
          >
            {loading ? "Mengirim kode..." : "Kirim Kode OTP"}
          </button>
        </div>
      ) : (
        <div className="mt-5">
          <label className="text-[11px] uppercase tracking-wide text-muted">
            Kode OTP dikirim ke {phone}
          </label>
          <input
            value={otp}
            onChange={(e) => setOtp(e.target.value)}
            placeholder="••••••"
            inputMode="numeric"
            className="mt-1.5 w-full rounded-xl border border-line px-3 py-2.5 text-center text-[18px] tracking-[0.4em] outline-none focus:border-ink"
          />
          <button
            onClick={verifyOtp}
            disabled={loading || otp.length < 4}
            className="btn-primary mt-4 w-full py-3 text-[13.5px] font-semibold"
          >
            {loading ? "Memverifikasi..." : "Verifikasi & Masuk"}
          </button>
        </div>
      )}
    </div>
  );
}
