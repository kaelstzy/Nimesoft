import { PackageTier } from "@/lib/packages";
import { formatRupiah } from "@/lib/format";

type OrderSummaryProps = {
  pkg: PackageTier;
  days: number;
  total: number;
};

export default function OrderSummary({ pkg, days, total }: OrderSummaryProps) {
  return (
    <div className="card-cut mx-5 mt-4 border border-line p-5">
      <p className="text-[11px] uppercase tracking-wide text-muted">Pesanan</p>
      <p className="mt-1 text-[16px] font-semibold">{pkg.name}</p>
      <p className="mt-0.5 text-[12.5px] text-muted">{days} hari</p>
      <div className="mt-4 flex items-center justify-between border-t border-line pt-3">
        <span className="text-[12.5px] text-muted">Total</span>
        <span className="text-[17px] font-bold">{formatRupiah(total)}</span>
      </div>
    </div>
  );
}
