"use client";

import { useState } from "react";
import { PackageScope } from "@/lib/packages";

type RecipientFormProps = {
  scope: PackageScope;
  onConfirmed: (target: string) => void;
};

type CheckState = "idle" | "checking" | "found" | "not-found";

export default function RecipientForm({ scope, onConfirmed }: RecipientFormProps) {
  const [value, setValue] = useState("");
  const [check, setCheck] = useState<CheckState>("idle");
  const [detail, setDetail] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  // TODO: ganti dengan panggilan endpoint bot (/check-user atau ambil info invite link)
  function runCheck() {
    if (!value) return;
    setCheck("checking");
    setTimeout(() => {
      if (scope === "personal") {
        setDetail("Kaelzyy");
        setCheck("found");
      } else {
        setDetail("Grup: Warkop Malam · 84 anggota");
        setCheck("found");
      }
    }, 900);
  }

  return (
    <div className="mx-5 mt-4">
      <p className="text-[11px] uppercase tracking-wide text-muted">
        {scope === "personal" ? "Nomor WhatsApp Penerima" : "Link Undangan Grup"}
      </p>

      <div className="mt-1.5 flex gap-2">
        <input
          value={value}
          onChange={(e) => {
            setValue(e.target.value);
            setCheck("idle");
            setConfirmed(false);
          }}
          placeholder={scope === "personal" ? "628xxxxxxxxxx" : "https://chat.whatsapp.com/..."}
          className="w-full flex-1 border border-line px-3 py-2.5 text-[14px] outline-none focus:border-ink"
        />
        <button
          onClick={runCheck}
          disabled={!value || check === "checking"}
          className="shrink-0 border border-ink px-4 text-[12.5px] font-semibold disabled:opacity-40"
        >
          {check === "checking" ? "..." : "Cek"}
        </button>
      </div>

      {check === "found" && (
        <div className="mt-3 border border-line p-3">
          <p className="text-[12.5px] font-medium">
            {scope === "personal" ? "Nomor terdaftar sebagai:" : "Ditemukan:"}
          </p>
          <p className="mt-0.5 text-[13.5px] font-semibold">{detail}</p>
          <p className="mt-1 text-[11.5px] text-muted">
            {scope === "personal"
              ? "Pastikan ini nomor yang benar sebelum melanjutkan."
              : "Pastikan ini grup yang benar sebelum melanjutkan."}
          </p>
          <label className="mt-3 flex items-start gap-2 text-[12px]">
            <input
              type="checkbox"
              checked={confirmed}
              onChange={(e) => setConfirmed(e.target.checked)}
              className="mt-0.5"
            />
            Ya, ini sudah benar.
          </label>
        </div>
      )}

      <button
        onClick={() => onConfirmed(value)}
        disabled={!confirmed}
        className="mt-4 w-full bg-ink py-3 text-[13.5px] font-semibold text-paper disabled:opacity-40"
      >
        Lanjut ke Pembayaran
      </button>
    </div>
  );
}
