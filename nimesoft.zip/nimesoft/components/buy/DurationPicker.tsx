"use client";

import { PackageTier } from "@/lib/packages";

type DurationPickerProps = {
  pkg: PackageTier;
  days: number;
  onChange: (days: number) => void;
};

export default function DurationPicker({ pkg, days, onChange }: DurationPickerProps) {
  if (!pkg.custom) {
    // Paket tetap - durasi sudah pasti, tidak perlu dipilih
    return null;
  }

  const MIN_DAYS = 3;

  return (
    <div className="mx-5 mt-4">
      <p className="text-[11px] uppercase tracking-wide text-muted">Jumlah Hari</p>
      <div className="mt-2 flex items-center overflow-hidden rounded-xl border border-line">
        <button
          onClick={() => onChange(Math.max(MIN_DAYS, days - 1))}
          className="flex h-11 w-11 items-center justify-center text-[18px]"
          aria-label="Kurangi hari"
        >
          −
        </button>
        <div className="flex-1 text-center text-[15px] font-semibold">{days} hari</div>
        <button
          onClick={() => onChange(days + 1)}
          className="flex h-11 w-11 items-center justify-center text-[18px]"
          aria-label="Tambah hari"
        >
          +
        </button>
      </div>
      <p className="mt-1.5 text-[11px] text-muted">Minimum {MIN_DAYS} hari.</p>
    </div>
  );
}
