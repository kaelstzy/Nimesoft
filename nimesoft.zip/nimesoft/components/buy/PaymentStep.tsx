"use client";

import { useEffect, useState } from "react";
import { formatRupiah } from "@/lib/format";

type Status = "pending" | "success" | "failed";

type PaymentStepProps = {
  total: number;
};

// TODO: ganti simulasi ini dengan webhook Pakasir (payment_status)
// dan callback dari endpoint /activate di bot (activation_status)
export default function PaymentStep({ total }: PaymentStepProps) {
  const [paymentStatus, setPaymentStatus] = useState<Status>("pending");
  const [activationStatus, setActivationStatus] = useState<Status>("pending");

  useEffect(() => {
    const t1 = setTimeout(() => setPaymentStatus("success"), 2200);
    const t2 = setTimeout(() => setActivationStatus("success"), 3600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  const done = paymentStatus === "success" && activationStatus === "success";

  return (
    <div className="mx-5 mt-4">
      <div className="card-cut border border-line p-5 text-center">
        <p className="text-[11px] uppercase tracking-wide text-muted">Scan QRIS · Pakasir</p>
        <div className="mx-auto mt-3 flex h-40 w-40 items-center justify-center border border-line text-[11px] text-muted">
          QR Code
        </div>
        <p className="mt-3 text-[18px] font-bold">{formatRupiah(total)}</p>
      </div>

      <div className="mt-4 divide-y divide-line border border-line">
        <StatusRow label="Pembayaran" status={paymentStatus} />
        <StatusRow label="Aktivasi Paket" status={activationStatus} />
      </div>

      {done ? (
        <p className="mt-4 text-center text-[13px] font-medium">
          Paket kamu sudah aktif. Cek di halaman Profile.
        </p>
      ) : (
        <p className="mt-4 text-center text-[12px] text-muted">
          Halaman ini akan otomatis update setelah pembayaran terkonfirmasi.
        </p>
      )}
    </div>
  );
}

function StatusRow({ label, status }: { label: string; status: Status }) {
  return (
    <div className="flex items-center justify-between px-4 py-3">
      <span className="text-[13px]">{label}</span>
      <span
        className={`text-[11.5px] font-medium ${
          status === "success"
            ? "text-black"
            : status === "failed"
            ? "text-black/40 line-through"
            : "text-black/40"
        }`}
      >
        {status === "success" ? "Berhasil" : status === "failed" ? "Gagal" : "Memproses..."}
      </span>
    </div>
  );
}
