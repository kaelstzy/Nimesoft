"use client";

import { useMemo, useState } from "react";
import { useSearchParams } from "next/navigation";
import { PACKAGES } from "@/lib/packages";
import LoginGate from "@/components/buy/LoginGate";
import OrderSummary from "@/components/buy/OrderSummary";
import DurationPicker from "@/components/buy/DurationPicker";
import RecipientForm from "@/components/buy/RecipientForm";
import PaymentStep from "@/components/buy/PaymentStep";

type Step = "duration" | "recipient" | "payment";

export default function BuyWizard() {
  const params = useSearchParams();
  const packageId = params.get("package") ?? "vip-user";
  const pkg = useMemo(
    () => PACKAGES.find((p) => p.id === packageId) ?? PACKAGES[0],
    [packageId]
  );

  const [loggedIn, setLoggedIn] = useState(false);
  const [days, setDays] = useState(pkg.custom ? 3 : 30);
  const [step, setStep] = useState<Step>("duration");
  const [target, setTarget] = useState<string | null>(null);

  const total = pkg.custom ? pkg.price * days : pkg.price;

  if (!loggedIn) {
    return <LoginGate onLoggedIn={() => setLoggedIn(true)} />;
  }

  return (
    <>
      <OrderSummary pkg={pkg} days={days} total={total} />

      {step === "duration" && (
        <>
          <DurationPicker pkg={pkg} days={days} onChange={setDays} />
          <div className="mx-5 mt-4">
            <button
              onClick={() => setStep("recipient")}
              className="btn-primary w-full py-3 text-[13.5px] font-semibold"
            >
              Lanjut
            </button>
          </div>
        </>
      )}

      {step === "recipient" && (
        <RecipientForm
          scope={pkg.scope}
          onConfirmed={(value) => {
            setTarget(value);
            setStep("payment");
          }}
        />
      )}

      {step === "payment" && target && <PaymentStep total={total} />}
    </>
  );
}
