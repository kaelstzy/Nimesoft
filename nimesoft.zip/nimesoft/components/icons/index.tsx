import { SVGProps } from "react";

type IconProps = SVGProps<SVGSVGElement>;

export const IconHome = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
    <path d="M4 11.5 12 4l8 7.5" strokeLinecap="round" strokeLinejoin="round" />
    <path d="M6 10v9a1 1 0 0 0 1 1h3v-6h4v6h3a1 1 0 0 0 1-1v-9" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const IconPricing = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
    <path d="M3 12 12 3l8 1 1 8-9 9-9-9Z" strokeLinejoin="round" />
    <circle cx="15.5" cy="8.5" r="1.4" />
  </svg>
);

export const IconBuy = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
    <path d="M6 7h13l-1.4 8.4a2 2 0 0 1-2 1.6H8.6a2 2 0 0 1-2-1.7L5 4H3" strokeLinecap="round" strokeLinejoin="round" />
    <circle cx="9.5" cy="20" r="1.2" />
    <circle cx="16.5" cy="20" r="1.2" />
  </svg>
);

export const IconJadibot = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
    <rect x="5" y="8" width="14" height="11" rx="2.5" />
    <path d="M9 8V6a3 3 0 0 1 6 0v2" strokeLinecap="round" />
    <circle cx="9.7" cy="13.2" r="1" fill="currentColor" stroke="none" />
    <circle cx="14.3" cy="13.2" r="1" fill="currentColor" stroke="none" />
    <path d="M10 16.2c.7.6 3.3.6 4 0" strokeLinecap="round" />
  </svg>
);

export const IconProfile = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
    <circle cx="12" cy="8" r="3.4" />
    <path d="M5 20c1.2-3.6 4-5.4 7-5.4s5.8 1.8 7 5.4" strokeLinecap="round" />
  </svg>
);

export const IconBug = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <rect x="8" y="8" width="8" height="9" rx="4" />
    <path d="M12 8V5M9 6l-1.5-1.5M15 6l1.5-1.5M6 12H3M21 12h-3M6 16l-2 2M18 16l2 2M9 17v2M15 17v2" strokeLinecap="round" />
  </svg>
);

export const IconSignal = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <path d="M5 19v-4M10 19v-8M15 19V7M20 19V4" strokeLinecap="round" />
  </svg>
);

export const IconInfo = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 11v5.5M12 8v.01" strokeLinecap="round" />
  </svg>
);

export const IconChannel = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <path d="M4 4h13l3 3v13H4z" strokeLinejoin="round" />
    <path d="M8 10h9M8 14h6" strokeLinecap="round" />
  </svg>
);

export const IconRedeem = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" {...p}>
    <rect x="4" y="9" width="16" height="10" rx="1.5" />
    <path d="M4 13h16M12 9v10" strokeLinecap="round" />
    <path
      d="M12 9c-1.6 0-3-1-3-2.3C9 5.6 9.8 5 10.6 5c1 0 1.4.9 1.4 1.7M12 9c1.6 0 3-1 3-2.3C15 5.6 14.2 5 13.4 5c-1 0-1.4.9-1.4 1.7"
      strokeLinecap="round"
    />
  </svg>
);

export const IconChevron = (p: IconProps) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
    <path d="m9 6 6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);
