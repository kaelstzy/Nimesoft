import Link from "next/link";
import { IconInfo } from "@/components/icons";

type HeaderProps = {
  name: string;
  uid: string;
  initials: string;
};

export default function Header({ name, uid, initials }: HeaderProps) {
  return (
    <header className="flex items-center justify-between px-5 pt-6 pb-2">
      <Link href="/profile/edit" className="flex items-center gap-3 text-left">
        <span className="flex h-11 w-11 items-center justify-center rounded-full border border-line text-sm font-semibold">
          {initials}
        </span>
        <span>
          <span className="block text-[15px] font-semibold leading-tight">{name}</span>
          <span className="block text-[12px] text-muted">UID · {uid}</span>
        </span>
      </Link>
      <Link
        href="/info"
        className="flex h-9 w-9 items-center justify-center border border-line"
        aria-label="Info"
      >
        <IconInfo className="h-4.5 w-4.5 text-black/60" />
      </Link>
    </header>
  );
}
