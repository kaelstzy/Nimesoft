"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  IconHome,
  IconPricing,
  IconBuy,
  IconJadibot,
  IconProfile,
} from "@/components/icons";

const NAV_ITEMS = [
  { href: "/", label: "Home", icon: IconHome },
  { href: "/pricing", label: "Pricing", icon: IconPricing },
  { href: "/buy", label: "BUY", icon: IconBuy, primary: true },
  { href: "/jadibot", label: "Jadibot", icon: IconJadibot },
  { href: "/profile", label: "Profile", icon: IconProfile },
] as const;

export default function BottomNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed inset-x-0 bottom-0 z-20 mx-auto flex max-w-sm items-end justify-between border-t border-line bg-paper/95 px-5 pb-4 pt-2 backdrop-blur">
      {NAV_ITEMS.map(({ href, label, icon: Icon, primary }) => {
        const active = pathname === href;

        if (primary) {
          return (
            <Link key={href} href={href} className="flex -translate-y-3 flex-col items-center gap-1">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-paper shadow-lg shadow-accent/30">
                <Icon className="h-5 w-5" />
              </span>
              <span className="text-[10px] font-semibold">{label}</span>
            </Link>
          );
        }

        return (
          <Link
            key={href}
            href={href}
            className={`flex flex-col items-center gap-1 px-2 pt-2 ${
              active ? "text-accent" : "text-black/40 hover:text-ink"
            }`}
          >
            <Icon className="h-5 w-5" />
            <span className="text-[10px] font-medium">{label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
