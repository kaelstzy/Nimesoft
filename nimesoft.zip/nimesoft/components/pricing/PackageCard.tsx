import Link from "next/link";
import { PackageTier } from "@/lib/packages";

export default function PackageCard({ pkg }: { pkg: PackageTier }) {
  return (
    <div
      className={`card-cut flex w-[210px] shrink-0 flex-col justify-between border p-4 ${
        pkg.highlight ? "border-ink bg-ink text-paper" : "border-line bg-paper text-ink"
      }`}
    >
      <div>
        {pkg.custom && (
          <span
            className={`mb-2 inline-block border px-2 py-0.5 text-[10px] uppercase tracking-wide ${
              pkg.highlight ? "border-paper/30" : "border-black/15"
            }`}
          >
            Suka-Suka
          </span>
        )}
        <p className="text-[14px] font-semibold">{pkg.name}</p>
        <p className="mt-2 text-[19px] font-bold leading-none">{pkg.priceLabel}</p>
        <p className={`mt-1 text-[11px] ${pkg.highlight ? "text-paper/60" : "text-muted"}`}>
          {pkg.duration}
        </p>

        <ul className="mt-3 space-y-1.5">
          {pkg.benefits.map((b, i) => (
            <li key={i} className={`text-[11.5px] leading-snug ${pkg.highlight ? "text-paper/85" : "text-black/70"}`}>
              · {b}
            </li>
          ))}
        </ul>

        {pkg.nimeCoin && (
          <p className={`mt-3 text-[11px] font-medium ${pkg.highlight ? "text-paper/80" : "text-black/60"}`}>
            +{pkg.nimeCoin.toLocaleString("id-ID")} Nime Coin
          </p>
        )}
      </div>

      <Link
        href={`/pricing/${pkg.id}`}
        className={`mt-4 flex items-center justify-center py-2.5 text-[12.5px] font-semibold ${
          pkg.highlight ? "bg-paper text-ink" : "bg-ink text-paper"
        }`}
      >
        Lihat Detail
      </Link>
    </div>
  );
}
