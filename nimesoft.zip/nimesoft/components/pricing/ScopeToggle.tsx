import { PackageScope } from "@/lib/packages";

type ScopeToggleProps = {
  value: PackageScope;
  onChange: (scope: PackageScope) => void;
};

export default function ScopeToggle({ value, onChange }: ScopeToggleProps) {
  return (
    <div className="flex rounded-2xl border border-line p-1">
      <button
        onClick={() => onChange("personal")}
        className={`flex-1 rounded-xl py-2.5 text-[13px] font-medium transition-colors ${
          value === "personal" ? "bg-ink text-paper" : "bg-paper text-black/50"
        }`}
      >
        Personal
      </button>
      <button
        onClick={() => onChange("group")}
        className={`flex-1 rounded-xl py-2.5 text-[13px] font-medium transition-colors ${
          value === "group" ? "bg-ink text-paper" : "bg-paper text-black/50"
        }`}
      >
        Group
      </button>
    </div>
  );
}
