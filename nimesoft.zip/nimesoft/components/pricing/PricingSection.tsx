"use client";

import { useState } from "react";
import ScopeToggle from "@/components/pricing/ScopeToggle";
import PackageCard from "@/components/pricing/PackageCard";
import { PackageScope, packagesByScope } from "@/lib/packages";

export default function PricingSection() {
  const [scope, setScope] = useState<PackageScope>("personal");
  const packages = packagesByScope(scope);

  return (
    <section className="px-5">
      <ScopeToggle value={scope} onChange={setScope} />

      <div className="-mx-5 mt-5 flex gap-3 overflow-x-auto px-5 pb-2">
        {packages.map((pkg) => (
          <PackageCard key={pkg.id} pkg={pkg} />
        ))}
      </div>

      <p className="mt-4 text-[11.5px] leading-relaxed text-muted">
        Paket Suka-Suka dihitung per hari dan sedikit lebih mahal dari paket bulanan tetap —
        cocok kalau kamu cuma butuh aktif untuk beberapa hari saja.
      </p>
    </section>
  );
}
