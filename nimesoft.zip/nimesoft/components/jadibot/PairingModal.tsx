"use client";

import { useState } from "react";

type PairingModalProps = {
  code: string;
  onClose: () => void;
};

export default function PairingModal({ code, onClose }: PairingModalProps) {
  const [copied, setCopied] = useState(false);

  function copy() {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  return (
    <div className="fixed inset-0 z-30 flex items-end justify-center bg-black/40 sm:items-center">
      <div className="card-cut w-full max-w-sm border border-line bg-paper p-6">
        <p className="text-[11px] uppercase tracking-wide text-muted">Kode Pairing</p>

        <p className="mt-2 text-center text-[28px] font-bold tracking-[0.15em]">{code}</p>

        <button
          onClick={copy}
          className="mt-3 w-full border border-ink py-2.5 text-[12.5px] font-semibold"
        >
          {copied ? "Tersalin" : "Salin Kode"}
        </button>

        <div className="mt-5 border-t border-line pt-4">
          <p className="text-[11px] uppercase tracking-wide text-muted">Cara Memasukkan Kode</p>
          <ol className="mt-2 space-y-1.5 text-[12.5px] leading-snug text-black/70">
            <li>1. Buka WhatsApp → Pengaturan → Perangkat Tertaut</li>
            <li>2. Pilih &quot;Tautkan dengan nomor telepon&quot;</li>
            <li>3. Masukkan kode di atas pada WhatsApp kamu</li>
          </ol>
        </div>

        <button onClick={onClose} className="mt-5 w-full py-2.5 text-[12.5px] font-medium text-muted">
          Tutup
        </button>
      </div>
    </div>
  );
}
