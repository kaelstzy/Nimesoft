"use client";

import { useState } from "react";

type PairingFormProps = {
  onPaired: (code: string) => void;
};

export default function PairingForm({ onPaired }: PairingFormProps) {
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);

  // TODO: ganti dengan panggilan endpoint bot (/pairing) yang generate kode asli
  function submit() {
    if (!phone) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const mockCode = "N3M7-KX92";
      onPaired(mockCode);
    }, 1400);
  }

  return (
    <div className="mx-5 mt-4">
      <p className="text-[11px] uppercase tracking-wide text-muted">Nomor WhatsApp</p>
      <input
        value={phone}
        onChange={(e) => setPhone(e.target.value)}
        placeholder="628xxxxxxxxxx"
        inputMode="numeric"
        disabled={loading}
        className="mt-1.5 w-full rounded-xl border border-line px-3 py-2.5 text-[14px] outline-none focus:border-ink disabled:opacity-50"
      />
      <button
        onClick={submit}
        disabled={loading || !phone}
        className="btn-primary mt-3 w-full py-3 text-[13.5px] font-semibold"
      >
        {loading ? "Menghubungkan..." : "Buat Kode Pairing"}
      </button>
    </div>
  );
}
