export default function Disclaimer() {
  return (
    <div className="mx-5 mt-4 border border-line p-4">
      <p className="text-[11px] uppercase tracking-wide text-muted">Disclaimer Layanan Jadibot</p>
      <p className="mt-2 text-[12px] leading-relaxed text-black/70">
        NimeSoft merupakan penyedia layanan (service provider) yang memfasilitasi penggunaan
        Jadibot berbasis nomor WhatsApp pribadi Anda. Penggunaan nomor WhatsApp sepenuhnya
        menjadi tanggung jawab Anda pribadi. Jadibot adalah layanan otomatisasi pihak ketiga
        yang tidak diafiliasikan secara resmi dengan WhatsApp Inc., sehingga risiko pembatasan
        fitur maupun pemblokiran akun berada di luar kendali NimeSoft maupun Heion Studios.
      </p>
      <a href="/kebijakan" className="mt-2 inline-block text-[11.5px] font-medium underline">
        Baca kebijakan & ketentuan lengkap
      </a>
    </div>
  );
}
