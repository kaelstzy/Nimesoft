type ActiveBotCardProps = {
  phone: string;
  connectedSince: string;
};

export default function ActiveBotCard({ phone, connectedSince }: ActiveBotCardProps) {
  return (
    <div className="card-cut mx-5 mt-4 flex items-center justify-between border border-line p-4">
      <div>
        <p className="text-[11px] uppercase tracking-wide text-muted">Aktif sebagai Jadibot</p>
        <p className="mt-1 text-[14.5px] font-semibold">{phone}</p>
        <p className="mt-0.5 text-[11.5px] text-muted">Terhubung sejak {connectedSince}</p>
      </div>
      <span className="flex h-2.5 w-2.5 rounded-full bg-black" />
    </div>
  );
}
