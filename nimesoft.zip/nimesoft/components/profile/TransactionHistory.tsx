import { formatRupiah } from "@/lib/format";

export type Transaction = {
  id: string;
  packageName: string;
  date: string;
  amount: number;
  status: "Berhasil" | "Pending" | "Gagal";
};

export default function TransactionHistory({ items }: { items: Transaction[] }) {
  return (
    <section className="mt-7 px-5 pb-28">
      <p className="mb-3 text-[11px] uppercase tracking-wide text-muted">Riwayat Transaksi</p>

      {items.length === 0 ? (
        <p className="text-[12.5px] text-muted">Belum ada transaksi.</p>
      ) : (
        <div className="divide-y divide-line rounded-xl border border-line">
          {items.map((tx) => (
            <div key={tx.id} className="px-4 py-3">
              <div className="flex items-center justify-between">
                <span className="text-[13.5px] font-medium">{tx.packageName}</span>
                <span className="text-[13.5px] font-semibold">{formatRupiah(tx.amount)}</span>
              </div>
              <div className="mt-1 flex items-center justify-between">
                <span className="text-[11.5px] text-muted">{tx.date}</span>
                <span
                  className={`rounded-full border px-2 py-0.5 text-[10.5px] font-medium ${
                    tx.status === "Berhasil"
                      ? "border-black/20"
                      : tx.status === "Pending"
                      ? "border-black/10 text-muted"
                      : "border-black/10 text-black/40 line-through"
                  }`}
                >
                  {tx.status}
                </span>
              </div>
              <p className="mt-1 text-[10.5px] text-black/35">ID {tx.id}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
