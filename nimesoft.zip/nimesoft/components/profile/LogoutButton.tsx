"use client";

export default function LogoutButton() {
  // TODO: hapus sesi login (nomor WA + OTP) beneran, lalu redirect ke halaman utama
  function logout() {
    console.log("logout");
  }

  return (
    <div className="px-5">
      <button
        onClick={logout}
        className="w-full border border-line py-3 text-[13px] font-semibold text-black/60"
      >
        Keluar
      </button>
    </div>
  );
}
