export type ActiveStatus = {
  label: string;
  expiresLabel: string;
};

export default function StatusList({ items }: { items: ActiveStatus[] }) {
  return (
    <section className="mt-2 px-5">
      <p className="mb-3 text-[11px] uppercase tracking-wide text-muted">Status Paket</p>

      {items.length === 0 ? (
        <div className="card-cut border border-line p-4 text-[12.5px] text-muted">
          Belum ada paket aktif. Lihat{" "}
          <a href="/pricing" className="font-medium underline text-ink">
            Pricing
          </a>
          .
        </div>
      ) : (
        <div className="divide-y divide-line border border-line">
          {items.map((item, i) => (
            <div key={i} className="flex items-center justify-between px-4 py-3">
              <span className="text-[13.5px] font-medium">{item.label}</span>
              <span className="text-[11.5px] text-muted">s.d. {item.expiresLabel}</span>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
