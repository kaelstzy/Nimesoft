import Link from "next/link";

type ProfileHeaderProps = {
  name: string;
  uid: string;
  phone: string;
  initials: string;
};

export default function ProfileHeader({ name, uid, phone, initials }: ProfileHeaderProps) {
  return (
    <section className="flex flex-col items-center px-5 pt-8 pb-6 text-center">
      <span className="flex h-20 w-20 items-center justify-center rounded-full border border-line text-[22px] font-semibold">
        {initials}
      </span>
      <p className="mt-3 text-[17px] font-semibold">{name}</p>
      <p className="mt-0.5 text-[12.5px] text-muted">UID · {uid}</p>
      <p className="text-[12.5px] text-muted">{phone}</p>

      <Link
        href="/profile/edit"
        className="mt-4 border border-ink px-5 py-2 text-[12.5px] font-semibold"
      >
        Edit Profil
      </Link>
    </section>
  );
}
