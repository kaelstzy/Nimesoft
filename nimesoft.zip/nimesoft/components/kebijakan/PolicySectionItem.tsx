"use client";

import { useState } from "react";
import { PolicySection as PolicySectionType } from "@/lib/policy";
import { IconChevron } from "@/components/icons";

export default function PolicySectionItem({ section }: { section: PolicySectionType }) {
  const [open, setOpen] = useState(false);

  return (
    <div id={section.id} className="border-b border-line">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex w-full items-center justify-between py-4 text-left"
      >
        <span className="text-[14px] font-semibold">{section.title}</span>
        <IconChevron className={`h-4 w-4 transition-transform ${open ? "rotate-90" : ""}`} />
      </button>

      {open && (
        <div className="pb-4">
          {section.paragraphs.map((p, i) => (
            <p key={i} className="mb-3 text-[12.5px] leading-relaxed text-black/70">
              {p}
            </p>
          ))}
          {section.list && (
            <ul className="space-y-1.5">
              {section.list.map((item, i) => (
                <li key={i} className="text-[12.5px] leading-snug text-black/70">
                  · {item}
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
