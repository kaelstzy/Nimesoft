export type PolicySection = {
  id: string;
  title: string;
  paragraphs: string[];
  list?: string[];
};

export const POLICY_SECTIONS: PolicySection[] = [
  {
    id: "privasi",
    title: "Kebijakan Privasi",
    paragraphs: [
      "NimeSoft hanya mengumpulkan data yang benar-benar diperlukan untuk menjalankan layanan, seperti nomor WhatsApp dan riwayat transaksi. NimeSoft tidak mengumpulkan maupun menyimpan data sensitif pengguna.",
      "Data yang dikumpulkan tidak dibagikan ke pihak ketiga di luar kebutuhan operasional layanan (misalnya penyedia payment gateway untuk memproses pembayaran).",
    ],
  },
  {
    id: "refund",
    title: "Kebijakan Refund",
    paragraphs: [
      "Paket yang sudah berhasil aktif tidak dapat dikembalikan (no refund).",
      "Jika pembelian gagal diproses (pembayaran berhasil namun paket tidak aktif), pengguna dapat mengajukan klaim dengan mengirimkan tangkapan layar kegagalan beserta bukti invoice kepada admin/owner untuk diproses secara manual.",
    ],
  },
  {
    id: "ketentuan-layanan",
    title: "Ketentuan Layanan",
    paragraphs: [
      "NimeSoft merupakan penyedia layanan (service provider) yang memfasilitasi penggunaan Jadibot berbasis nomor WhatsApp pribadi pengguna. Penggunaan nomor WhatsApp sepenuhnya menjadi tanggung jawab pengguna. Jadibot adalah layanan otomatisasi pihak ketiga yang tidak diafiliasikan secara resmi dengan WhatsApp Inc., sehingga risiko pembatasan fitur maupun pemblokiran akun berada di luar kendali NimeSoft maupun Heion Studios.",
      "Dengan menggunakan layanan ini, pengguna dianggap telah membaca dan menyetujui seluruh ketentuan berikut:",
    ],
    list: [
      "Dilarang menggunakan bot untuk melakukan spam",
      "Dilarang menyebarkan tautan phishing melalui bot",
      "Dilarang menggunakan bot untuk tujuan komersial seperti menyewakan bot ke pihak lain (bot tetap boleh membantu keperluan komersial pengguna, misalnya HD foto untuk UMKM)",
      "Maksimal penggunaan bot pada 5 grup",
      "Dilarang menggunakan bot untuk konten ilegal atau NSFW",
      "Dilarang menggunakan bot untuk harassment atau bullying terhadap pihak lain",
      "NimeSoft berhak melakukan suspend atau banned akses tanpa refund apabila ditemukan pelanggaran",
      "Logo, nama, source code, dan seluruh aset visual NimeSoft merupakan Hak Kekayaan Intelektual (HKI) milik sah NimeSoft. Penyalahgunaan, termasuk peniruan atau penyebaran tanpa izin, dapat dikenakan tindakan hukum",
      "NimeSoft berkomitmen tidak akan menyebarkan source code bot kepada pihak manapun",
    ],
  },
];
