export type PackageScope = "personal" | "group";

export type PackageTier = {
  id: string;
  scope: PackageScope;
  name: string;
  price: number;
  priceLabel: string;
  duration: string;
  benefits: string[];
  nimeCoin?: number;
  highlight?: boolean;
  custom?: boolean;
};

export const PACKAGES: PackageTier[] = [
  {
    id: "premium-user",
    scope: "personal",
    name: "Premium",
    price: 12000,
    priceLabel: "Rp12.000",
    duration: "30 hari",
    benefits: ["Limit 500 command/hari", "Buka beberapa fitur terkunci", "Kenaikan EXP lebih cepat"],
    nimeCoin: 2000,
  },
  {
    id: "vip-user",
    scope: "personal",
    name: "VIP",
    price: 25000,
    priceLabel: "Rp25.000",
    duration: "30 hari",
    benefits: ["Limit unlimited/hari", "Akses lengkap ke semua fitur", "Kenaikan EXP lebih cepat"],
    nimeCoin: 5000,
    highlight: true,
  },
  {
    id: "premium-user-custom",
    scope: "personal",
    name: "Premium Suka-Suka",
    price: 500,
    priceLabel: "Rp500 / hari",
    duration: "Atur sendiri jumlah hari",
    benefits: ["Sama seperti Premium", "Fleksibel, bayar sesuai kebutuhan"],
    custom: true,
  },
  {
    id: "vip-user-custom",
    scope: "personal",
    name: "VIP Suka-Suka",
    price: 1000,
    priceLabel: "Rp1.000 / hari",
    duration: "Atur sendiri jumlah hari",
    benefits: ["Sama seperti VIP", "Fleksibel, bayar sesuai kebutuhan"],
    custom: true,
  },
  {
    id: "group-vip",
    scope: "group",
    name: "Group VIP",
    price: 15000,
    priceLabel: "Rp15.000",
    duration: "30 hari",
    benefits: ["Buka fitur terkunci untuk group", "Menghilangkan iklan di group"],
    highlight: true,
  },
];

export function packagesByScope(scope: PackageScope) {
  return PACKAGES.filter((p) => p.scope === scope);
}
