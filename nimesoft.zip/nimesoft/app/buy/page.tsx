import { Suspense } from "react";
import BottomNav from "@/components/layout/BottomNav";
import BuyWizard from "@/components/buy/BuyWizard";

export default function BuyPage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col">
      <header className="px-5 pt-6 pb-2">
        <h1 className="text-[20px] font-semibold">Selesaikan Pembelian</h1>
      </header>

      <Suspense fallback={null}>
        <BuyWizard />
      </Suspense>

      <div className="pb-28" />
      <BottomNav />
    </div>
  );
}
