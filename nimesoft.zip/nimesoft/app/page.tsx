import Header from "@/components/layout/Header";
import BottomNav from "@/components/layout/BottomNav";
import ActivePackageCard from "@/components/home/ActivePackageCard";
import FeatureGrid from "@/components/home/FeatureGrid";
import Changelog, { ChangelogEntry } from "@/components/home/Changelog";

// Sementara pakai data dummy - nanti diganti fetch dari Firestore
const CHANGELOG: ChangelogEntry[] = [
  { date: "20 Jul", text: "Fitur Redeem Code kini bisa dipakai langsung dari Home." },
  { date: "14 Jul", text: "Perbaikan stabilitas koneksi pairing code." },
  { date: "05 Jul", text: "Penambahan limit harian untuk paket Premium." },
];

export default function HomePage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col">
      <Header name="Kaelzyy" uid="NM-104822" initials="KZ" />
      <ActivePackageCard
        packageName="Group VIP"
        expiresLabel="19 Agu 2026"
        daysLeft={18}
        totalDays={30}
      />
      <FeatureGrid />
      <Changelog entries={CHANGELOG} />
      <BottomNav />
    </div>
  );
}
