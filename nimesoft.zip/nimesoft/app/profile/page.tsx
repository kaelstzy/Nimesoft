import BottomNav from "@/components/layout/BottomNav";
import ProfileHeader from "@/components/profile/ProfileHeader";
import StatusList, { ActiveStatus } from "@/components/profile/StatusList";
import TransactionHistory, { Transaction } from "@/components/profile/TransactionHistory";
import LogoutButton from "@/components/profile/LogoutButton";

// Sementara dummy - nanti diganti fetch dari Firestore
const ACTIVE_STATUS: ActiveStatus[] = [
  { label: "Group VIP", expiresLabel: "19 Agu 2026" },
];

const TRANSACTIONS: Transaction[] = [
  { id: "NM-88213", packageName: "Group VIP · 30 hari", date: "20 Jul 2026", amount: 15000, status: "Berhasil" },
  { id: "NM-88034", packageName: "Premium · 30 hari", date: "12 Jun 2026", amount: 12000, status: "Berhasil" },
];

export default function ProfilePage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col">
      <ProfileHeader name="Kaelzyy" uid="NM-104822" phone="+62 812-xxxx-xxxx" initials="KZ" />
      <StatusList items={ACTIVE_STATUS} />
      <TransactionHistory items={TRANSACTIONS} />
      <div className="mb-6">
        <LogoutButton />
      </div>
      <BottomNav />
    </div>
  );
}
