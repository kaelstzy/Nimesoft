"use client";

import { useState } from "react";
import Link from "next/link";

export default function EditProfilePage() {
  const [name, setName] = useState("Kaelzyy");

  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col px-5 pt-6 pb-10">
      <Link href="/profile" className="text-[12.5px] text-muted">
        ← Kembali ke Profile
      </Link>

      <h1 className="mt-4 text-[20px] font-semibold">Edit Profil</h1>

      <div className="mt-6">
        <label className="text-[11px] uppercase tracking-wide text-muted">Nama</label>
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="mt-1.5 w-full rounded-xl border border-line px-3 py-2.5 text-[14px] outline-none focus:border-ink"
        />
      </div>

      {/* TODO: nomor WA & UID tidak diedit di sini karena jadi identitas sistem */}

      <button className="mt-6 w-full rounded-xl bg-ink py-3 text-[13.5px] font-semibold text-paper">
        Simpan Perubahan
      </button>
    </div>
  );
}
