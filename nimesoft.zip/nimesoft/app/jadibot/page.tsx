"use client";

import { useState } from "react";
import BottomNav from "@/components/layout/BottomNav";
import ActiveBotCard from "@/components/jadibot/ActiveBotCard";
import Disclaimer from "@/components/jadibot/Disclaimer";
import PairingForm from "@/components/jadibot/PairingForm";
import PairingModal from "@/components/jadibot/PairingModal";

// Sementara dummy - nanti dicek dari data bot apakah user ini punya nomor aktif
const ACTIVE_BOT: { phone: string; connectedSince: string } | null = null;

export default function JadibotPage() {
  const [pairingCode, setPairingCode] = useState<string | null>(null);

  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col">
      <header className="px-5 pt-6 pb-2">
        <h1 className="text-[20px] font-semibold">Jadibot</h1>
        <p className="mt-1 text-[13px] text-muted">Hubungkan nomor WhatsApp kamu ke NimeSoft.</p>
      </header>

      {ACTIVE_BOT && (
        <ActiveBotCard phone={ACTIVE_BOT.phone} connectedSince={ACTIVE_BOT.connectedSince} />
      )}

      <PairingForm onPaired={setPairingCode} />

      {/* Disclaimer tetap tampil, termasuk saat form di atas dalam kondisi loading */}
      <Disclaimer />

      <div className="pb-28" />
      <BottomNav />

      {pairingCode && (
        <PairingModal code={pairingCode} onClose={() => setPairingCode(null)} />
      )}
    </div>
  );
}
