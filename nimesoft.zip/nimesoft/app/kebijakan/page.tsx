import Link from "next/link";
import { POLICY_SECTIONS } from "@/lib/policy";
import PolicySectionItem from "@/components/kebijakan/PolicySectionItem";

export default function KebijakanPage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col px-5 pt-6 pb-14">
      <Link href="/" className="text-[12.5px] text-muted">
        ← Kembali
      </Link>

      <h1 className="mt-4 text-[20px] font-semibold">Kebijakan &amp; Ketentuan</h1>
      <p className="mt-1 text-[12.5px] text-muted">
        Berlaku untuk seluruh pengguna layanan NimeSoft, sebuah layanan di bawah Heion Studios.
      </p>

      <div className="mt-5 border-t border-line">
        {POLICY_SECTIONS.map((section) => (
          <PolicySectionItem key={section.id} section={section} />
        ))}
      </div>
    </div>
  );
}
