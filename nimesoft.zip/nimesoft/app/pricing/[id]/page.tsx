import Link from "next/link";
import { notFound } from "next/navigation";
import { PACKAGES } from "@/lib/packages";

export function generateStaticParams() {
  return PACKAGES.map((p) => ({ id: p.id }));
}

export default function PackageDetailPage({ params }: { params: { id: string } }) {
  const pkg = PACKAGES.find((p) => p.id === params.id);
  if (!pkg) return notFound();

  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col px-5 pt-6 pb-10">
      <Link href="/pricing" className="text-[12.5px] text-muted">
        ← Kembali ke Pricing
      </Link>

      <div className="card-cut mt-5 border border-line p-6">
        <p className="text-[12px] uppercase tracking-wide text-muted">{pkg.duration}</p>
        <h1 className="mt-1 text-[24px] font-semibold">{pkg.name}</h1>
        <p className="mt-2 text-[22px] font-bold">{pkg.priceLabel}</p>

        <div className="mt-5 border-t border-line pt-5">
          <p className="mb-2 text-[11px] uppercase tracking-wide text-muted">Benefit</p>
          <ul className="space-y-2">
            {pkg.benefits.map((b, i) => (
              <li key={i} className="text-[13.5px] leading-snug">
                · {b}
              </li>
            ))}
          </ul>
        </div>

        {pkg.nimeCoin && (
          <p className="mt-4 text-[12.5px] font-medium text-black/60">
            Setiap pembelian mendapat {pkg.nimeCoin.toLocaleString("id-ID")} Nime Coin, bisa
            ditukar untuk Premium atau VIP.
          </p>
        )}
      </div>

      <Link
        href={`/buy?package=${pkg.id}`}
        className="mt-6 flex items-center justify-center bg-ink py-3.5 text-[14px] font-semibold text-paper"
      >
        Lanjutkan
      </Link>
    </div>
  );
}
