import BottomNav from "@/components/layout/BottomNav";
import PricingSection from "@/components/pricing/PricingSection";

export default function PricingPage() {
  return (
    <div className="mx-auto flex min-h-screen max-w-sm flex-col">
      <header className="px-5 pt-6 pb-4">
        <h1 className="text-[20px] font-semibold">Pricing</h1>
        <p className="mt-1 text-[13px] text-muted">Pilih paket yang paling cocok buat kamu.</p>
      </header>

      <PricingSection />

      <div className="pb-28" />
      <BottomNav />
    </div>
  );
}
