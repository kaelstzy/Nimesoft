import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NimeSoft",
  description: "Layanan Jadibot WhatsApp oleh NimeSoft",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id">
      <body className="min-h-screen bg-paper text-ink antialiased">
        {children}
      </body>
    </html>
  );
}
