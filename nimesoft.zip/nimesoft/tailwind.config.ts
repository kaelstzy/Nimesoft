import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#000000",
        paper: "#FFFFFF",
        line: "rgba(0,0,0,0.10)",
        muted: "rgba(0,0,0,0.45)",
      },
      fontFamily: {
        sans: ["var(--font-geist)", "Inter", "system-ui", "sans-serif"],
      },
      clipPath: {
        cut: "polygon(0 0, 100% 0, 100% 82%, 82% 100%, 0 100%)",
      },
    },
  },
  plugins: [],
};
export default config;
