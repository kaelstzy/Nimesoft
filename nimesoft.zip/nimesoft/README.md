# NimeSoft

## Menjalankan project

```bash
npm install
npm run dev
```

Buka http://localhost:3000

## Struktur

- `app/` — halaman (App Router Next.js). Saat ini baru ada Home (`app/page.tsx`).
- `components/layout/` — Header & BottomNav, dipakai di semua halaman.
- `components/home/` — komponen khusus halaman Home (kartu paket, grid menu, changelog).
- `components/icons/` — semua ikon SVG custom (tanpa emoji), reusable lintas halaman.

## Status

- [x] Home
- [x] Pricing (+ halaman detail benefit paket)
- [x] BUY (login, durasi, verifikasi penerima, pembayaran)
- [x] Jadibot (input nomor, disclaimer persisten, popup kode pairing)
- [x] Profile (info dasar, edit profil, status paket, riwayat transaksi, logout)
- [x] Kebijakan & Ketentuan (Privasi, Refund, Ketentuan Layanan — accordion)
- [ ] Admin Panel

Data di Home masih dummy — nanti disambungkan ke Firestore (bot sebagai sumber data asli, Firestore sebagai cache untuk web).
